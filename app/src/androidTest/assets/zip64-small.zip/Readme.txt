ZIP64 preview fixture
